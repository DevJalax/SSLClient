package com.http.sslClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SslClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslClientApplication.class, args);
	}

}
