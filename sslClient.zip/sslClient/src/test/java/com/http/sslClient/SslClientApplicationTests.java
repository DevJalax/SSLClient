package com.http.sslClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SslClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
